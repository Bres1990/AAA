package com.jmj_studio.project;

/**
 * Created by Asia on 03.05.2015.
 */
public class ChildClass {
    private String name = "";

    public ChildClass(String name) {
        super();
        this.name = name;

    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
